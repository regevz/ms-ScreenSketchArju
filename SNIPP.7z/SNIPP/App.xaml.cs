﻿using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace SNIPP
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		private void Application_Startup(object sender, StartupEventArgs e)
	    {
			//MessageBox.Show ("dsds");
			
//			LaunchUri2();
//			Console.Write("Press dsdfsd. . . ");
	    }
		
	}
}